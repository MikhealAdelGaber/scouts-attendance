import{xa as t}from"./chunk-CJZ7JI6D.js";var e=new t(()=>!1);export{e as a};
